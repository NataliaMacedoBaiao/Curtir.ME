var searchData=
[
  ['postagem_0',['postagem',['../class_postagem.html',1,'Postagem'],['../class_postagem.html#a0ce2e2d19d707a67d53d5c0c648a1467',1,'Postagem::Postagem(int ID, int numeroP, char conteudo[])'],['../class_postagem.html#ab70d7af09da7441324472991c4daff88',1,'Postagem::Postagem()']]],
  ['printacomentario_1',['printaComentario',['../classmanipulador_de_comentario.html#adb4f4675386bb9cb65ad52c6e4efc3af',1,'manipuladorDeComentario']]],
  ['procurausuarioid_2',['procuraUsuarioId',['../classmanipulador_de_usuario.html#a704fb599e9094dc4820cb1a11d845bab',1,'manipuladorDeUsuario']]],
  ['procurausuarionome_3',['procuraUsuarioNome',['../classmanipulador_de_usuario.html#a7d1cf70176030c2d432837cf003c3a49',1,'manipuladorDeUsuario']]]
];
