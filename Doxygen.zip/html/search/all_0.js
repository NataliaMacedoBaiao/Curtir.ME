var searchData=
[
  ['adicionaaoarquivo_0',['adicionaaoarquivo',['../classmanipulador_de_comentario.html#ad07b2569ca02456812f188a7f5b06996',1,'manipuladorDeComentario::adicionaAoArquivo()'],['../classmanipulador_de_postagem.html#ad79cd6a1fe74182b52d76ace690d750b',1,'manipuladorDePostagem::adicionaAoArquivo(Postagem post)']]],
  ['adicionacurtida_1',['adicionaCurtida',['../classmanipulador_de_postagem.html#a3bd91eaa69b7132825e41010d46f671d',1,'manipuladorDePostagem']]],
  ['adicionahashtagarquivo_2',['adicionaHashtagArquivo',['../class_hashtag.html#a68cc73dc9403616fd7cd0c6cccdf8399',1,'Hashtag']]],
  ['apagarpostagem_3',['apagarPostagem',['../classmanipulador_de_postagem.html#aa162570f43d0656aea62cc267d9998d0',1,'manipuladorDePostagem']]],
  ['aumentarnumerodepostagens_4',['aumentarNumeroDePostagens',['../classmanipulador_de_postagem.html#abf28c56e1311e4c36d1a16eb6468b7d1',1,'manipuladorDePostagem']]],
  ['aumentarnumerodeusuarios_5',['aumentarNumeroDeUsuarios',['../classmanipulador_de_usuario.html#ae3dc0f8f42720abe61a3395208923ffd',1,'manipuladorDeUsuario']]],
  ['autenticarusuario_6',['autenticarUsuario',['../classmanipulador_de_usuario.html#a7c041f891c83c3a4d0befecf16cd91ff',1,'manipuladorDeUsuario']]]
];
