var indexSectionsWithContent =
{
  0: "abcdeghlmnprsuvz",
  1: "chmpu",
  2: "abcdeghlmnprsuvz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Funções"
};

