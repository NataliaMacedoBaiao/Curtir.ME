var searchData=
[
  ['limpararquivobinario_0',['limparArquivoBinario',['../classmanipulador_de_arquivo.html#a9ef60478cde152905916c28527e30bbc',1,'manipuladorDeArquivo']]],
  ['limpausuario_1',['limpaUsuario',['../class_usuario.html#adb0066ba4111ae4bd09c6525986d3c94',1,'Usuario']]]
];
