var searchData=
[
  ['mostrarfeed_0',['mostrarFeed',['../classmanipulador_de_postagem.html#a60a90cf95d17eb5e1dc973762e789852',1,'manipuladorDePostagem']]],
  ['mostrarfeeddosseguidos_1',['mostrarFeedDosSeguidos',['../classmanipulador_de_postagem.html#abdf8f07afa03978178b934d48ab81927',1,'manipuladorDePostagem']]],
  ['mostrarfeedporhashtag_2',['mostrarFeedPorHashtag',['../classmanipulador_de_postagem.html#ac11fde05e68b48e27700632a493455c1',1,'manipuladorDePostagem']]]
];
