var searchData=
[
  ['verificaexistencia_0',['verificaExistencia',['../class_hashtag.html#ac850762f6e9a21a6d766ced42ca4a5a0',1,'Hashtag']]],
  ['verificaformato_1',['verificaFormato',['../class_hashtag.html#a9c7c0905d4b1e607203740c1f6a01c34',1,'Hashtag']]]
];
