var searchData=
[
  ['buscapostagem_0',['buscaPostagem',['../classmanipulador_de_postagem.html#a5c75e4ca72c501fe3a5d2a3d679244df',1,'manipuladorDePostagem']]]
];
