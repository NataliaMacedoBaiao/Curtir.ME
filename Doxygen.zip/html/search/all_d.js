var searchData=
[
  ['usuario_0',['usuario',['../class_usuario.html',1,'Usuario'],['../class_usuario.html#aa85a5371a098dfba5449140d9b8a472f',1,'Usuario::Usuario()'],['../class_usuario.html#a384792503be8cb7cb61664e3d89fac81',1,'Usuario::Usuario(string nome, string senha, int id)']]]
];
